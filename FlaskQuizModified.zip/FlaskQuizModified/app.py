from flask import Flask, render_template, request, redirect, url_for, session

# Create the Flask app
app = Flask(__name__)

# Secret key for sessions that is used to store score and current question
app.secret_key = 'test'

# Questions for the quiz, answer options and correct answer
questions = [
    { "text": "Who was the Ancient Greek God of the Sun?",
        "options": ['Dionysus', 'Hermes', 'Apollo', 'Uranus'],
        "correct_option": 2  # Correct answer is "Apollo"
    },
    {
        "text": "How many cm in 1 inch?",
        "options": ['2.54', '1.96', '2.34', '2.04'],
        "correct_option": 0  # Correct answer is "2.54"
    },
    {
        "text": "What is the smallest unit of matter?",
        "options": ['Quarks', 'Ion', 'Molecules', 'Atom'],
        "correct_option": 3  # Correct answer is "Atom"
    }
]

# Route for the home page
@app.route('/', methods=['GET', 'POST'])
def index():
    # If the user clicks "Start Quiz"
    if request.method == 'POST':
        session['current_question'] = 0  # Start from the first question
        session['score'] = 0  # Reset the score to 0
        return redirect(url_for('quiz_view'))

    # If it's a GET request, show the start button
    return render_template('index.html')

# Route for the quiz page
@app.route('/quiz', methods=['GET', 'POST'])
def quiz_view():
    if request.method == 'POST':
        # Get the option selected by the user
        selected_option = request.form.get('option')
        current_question_index = session.get('current_question', 0)

        # If an option was selected, check if it's correct
        if selected_option:
            correct_option = questions[current_question_index]['correct_option']
            if int(selected_option) == correct_option:
                session['score'] += 1  # Add 1 to the score if correct

        # Move to the next question
        session['current_question'] += 1

        # If all questions are done, go to the results page
        if session['current_question'] >= len(questions):
            return redirect(url_for('results'))

    # Get the current question to show to the user
    current_question_index = session.get('current_question', 0)
    question = questions[current_question_index]
    return render_template('quiz.html', question=question, question_index=current_question_index + 1, total_questions=len(questions))

# Route for the results page
@app.route('/results')
def results():
    # Show the final score
    score = session.get('score', 0)
    total_questions = len(questions)
    return render_template('results.html', score=score, total_questions=total_questions)

# Run the app
if __name__ == '__main__':
    app.run()
